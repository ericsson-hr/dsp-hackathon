# DSP hackaton 2021
#
# Advanced task - wav file generator

#!/usr/bin/python

import sys
from scipy.io import wavfile
import numpy as np

f = open('exampleSamples.bin', "r")
a = np.fromfile(f, dtype='>i2')

fs=8192 # sampling frequency
wavfile.write('exampleSamples.wav',fs, a)

