% DSP hackaton 2021
%
% Advanced task - wav file generator

% Generate samples from bit file
fileID = fopen('exampleSamples.bin', 'r');
wavsamples=fread(fileID,'int16','b');
wavsamples=int16(wavsamples)
fclose(fileID);

fs3=8192;
audiowrite('exampleSound.wav', wavsamples,fs3);